#python2

def snapchatcre():
 try:
  target = "files/snapchat/l.txt"
  file = open(target, "r")
  text = file.read()
  file.close()
  print text
 except IOError:
  print ''
  print "No data found !"
  print ''

